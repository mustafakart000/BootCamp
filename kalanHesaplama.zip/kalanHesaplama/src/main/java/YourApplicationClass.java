import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YourApplicationClass {
    public static void main(String[] args) {
        SpringApplication.run(YourApplicationClass.class, args);
    }
}
